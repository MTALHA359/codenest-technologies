export default function AdminHome() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">Dashboard</h2>
      <p className="text-gray-700">Welcome to your software house admin panel.</p>

      {/* Add widgets here: project counts, new messages, etc. */}
    </div>
  );
}
